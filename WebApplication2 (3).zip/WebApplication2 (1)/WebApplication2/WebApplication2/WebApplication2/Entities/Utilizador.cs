﻿using System;
using System.Collections.Generic;

namespace WebApplication2.Entities;

public partial class Utilizador
{
    public decimal IdUtilizador { get; set; }

    public string Nome { get; set; } = null!;

    public string Username { get; set; } = null!;

    public string Password { get; set; } = null!;

    public decimal? NHabitualHoras { get; set; }

    public virtual ICollection<Membro> Membros { get; set; } = new List<Membro>();

    public virtual ICollection<Projeto> Projetos { get; set; } = new List<Projeto>();
}
