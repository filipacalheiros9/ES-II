﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using WebApplication2.Entities;

public class Tarefa
{
    [Key]
    public int IdTarefa { get; set; }

    public string NomeTarefa { get; set; }
    public DateOnly? DtInicio { get; set; }
    public TimeSpan HrInicio { get; set; }
    public DateOnly? DtFim { get; set; }
    public TimeSpan HrFim { get; set; }

    // Defina a chave estrangeira explicitamente:
    public decimal IdProjeto { get; set; }

    [ForeignKey("IdProjeto")]
    public virtual Projeto Projeto { get; set; }
}