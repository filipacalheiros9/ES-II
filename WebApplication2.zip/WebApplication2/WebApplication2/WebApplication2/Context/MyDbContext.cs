﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using WebApplication2.Entities;

namespace WebApplication2.Context;

public partial class MyDbContext : DbContext
{
    public MyDbContext()
    {
    }

    public MyDbContext(DbContextOptions<MyDbContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Membro> Membros { get; set; }

    public virtual DbSet<Projeto> Projetos { get; set; }

    public virtual DbSet<Tarefa> Tarefas { get; set; }

    public virtual DbSet<Utilizador> Utilizadors { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseNpgsql("Server=localhost;Database=es2;User Id=postgres;Password=@afilipaelinda;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Membro>(entity =>
        {
            entity.HasKey(e => e.IdMembro).HasName("Tarefa_pkey");

            entity.ToTable("Membro");

            entity.Property(e => e.IdMembro)
                .HasDefaultValueSql("50")
                .HasColumnName("id_membro");
            entity.Property(e => e.IdProjeto)
                .HasDefaultValueSql("8.0")
                .HasColumnName("id_projeto");
            entity.Property(e => e.IdUtilizador)
                .HasDefaultValueSql("8.0")
                .HasColumnName("id_utilizador");
            entity.Property(e => e.NHabitualHoras)
                .HasDefaultValueSql("8.0")
                .HasColumnName("n_habitual_horas");
            entity.Property(e => e.Nome)
                .HasDefaultValueSql("50")
                .HasColumnType("character varying")
                .HasColumnName("nome");
            entity.Property(e => e.Password)
                .HasDefaultValueSql("50")
                .HasColumnType("character varying")
                .HasColumnName("password");

            entity.HasOne(d => d.IdProjetoNavigation).WithMany(p => p.Membros)
                .HasForeignKey(d => d.IdProjeto)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("id_projeto");

            entity.HasOne(d => d.IdUtilizadorNavigation).WithMany(p => p.Membros)
                .HasForeignKey(d => d.IdUtilizador)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("id_utilizador");
        });

        modelBuilder.Entity<Projeto>(entity =>
        {
            entity.HasKey(e => e.IdProjeto).HasName("Projeto_pkey");

            entity.ToTable("Projeto");

            entity.Property(e => e.IdProjeto)
                .HasDefaultValueSql("8.0")
                .HasColumnName("id_projeto");
            entity.Property(e => e.IdUtilizador)
                .HasDefaultValueSql("8.0")
                .HasColumnName("id_utilizador");
            entity.Property(e => e.NomeCliente)
                .HasDefaultValueSql("50")
                .HasColumnType("character varying")
                .HasColumnName("nome_cliente");
            entity.Property(e => e.NomeProjeto)
                .HasDefaultValueSql("50")
                .HasColumnType("character varying")
                .HasColumnName("nome_projeto");
            entity.Property(e => e.PrecoHora)
                .HasDefaultValueSql("8.0")
                .HasColumnName("preco_hora");

            entity.HasOne(d => d.IdUtilizadorNavigation).WithMany(p => p.Projetos)
                .HasForeignKey(d => d.IdUtilizador)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("id_utilizador");
        });

        modelBuilder.Entity<Tarefa>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("Tarefa");

            entity.Property(e => e.DtFim).HasColumnName("dt_fim");
            entity.Property(e => e.DtInicio).HasColumnName("dt_inicio");
            entity.Property(e => e.HrFim)
                .HasDefaultValueSql("8")
                .HasColumnName("hr_fim");
            entity.Property(e => e.HrInicio)
                .HasDefaultValueSql("8")
                .HasColumnName("hr_inicio");
            entity.Property(e => e.IdProjeto).HasColumnName("id_projeto");
            entity.Property(e => e.IdTarefa).HasColumnName("id_tarefa");
            entity.Property(e => e.NomeTarefa)
                .HasDefaultValueSql("50")
                .HasColumnType("character varying")
                .HasColumnName("nome_tarefa");

            entity.HasOne(d => d.IdProjetoNavigation).WithMany()
                .HasForeignKey(d => d.IdProjeto)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("id_projeto");
        });

        modelBuilder.Entity<Utilizador>(entity =>
        {
            entity.HasKey(e => e.IdUtilizador).HasName("Utilizador_pkey");

            entity.ToTable("Utilizador");

            entity.Property(e => e.IdUtilizador)
                .HasDefaultValueSql("8.0")
                .HasColumnName("id_utilizador");
            entity.Property(e => e.NHabitualHoras)
                .HasDefaultValueSql("8.0")
                .HasColumnName("n_habitual_horas");
            entity.Property(e => e.Nome)
                .HasDefaultValueSql("50")
                .HasColumnType("character varying")
                .HasColumnName("nome");
            entity.Property(e => e.Password)
                .HasDefaultValueSql("50")
                .HasColumnType("character varying")
                .HasColumnName("password");
            entity.Property(e => e.Username)
                .HasDefaultValueSql("50")
                .HasColumnType("character varying")
                .HasColumnName("username");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
