﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;
using WebApplication2.Data;

#nullable disable

namespace WebApplication2.Migrations
{
    [DbContext(typeof(ApplicationDbContext))]
    partial class ApplicationDbContextModelSnapshot : ModelSnapshot
    {
        protected override void BuildModel(ModelBuilder modelBuilder)
        {
#pragma warning disable 612, 618
            modelBuilder
                .HasAnnotation("ProductVersion", "9.0.3")
                .HasAnnotation("Relational:MaxIdentifierLength", 63);

            NpgsqlModelBuilderExtensions.UseIdentityByDefaultColumns(modelBuilder);

            modelBuilder.Entity("WebApplication2.Entities.Membro", b =>
                {
                    b.Property<decimal>("IdMembro")
                        .HasColumnType("numeric");

                    b.Property<decimal>("IdProjeto")
                        .HasColumnType("numeric");

                    b.Property<decimal>("IdUtilizador")
                        .HasColumnType("numeric");

                    b.Property<decimal>("NHabitualHoras")
                        .HasColumnType("numeric");

                    b.Property<string>("Nome")
                        .IsRequired()
                        .HasColumnType("text");

                    b.Property<string>("Password")
                        .IsRequired()
                        .HasColumnType("text");

                    b.HasKey("IdMembro");

                    b.ToTable("Membros");
                });

            modelBuilder.Entity("WebApplication2.Entities.Projeto", b =>
                {
                    b.Property<decimal>("IdProjeto")
                        .HasColumnType("numeric");

                    b.Property<decimal>("IdUtilizador")
                        .HasColumnType("numeric");

                    b.Property<string>("NomeCliente")
                        .IsRequired()
                        .HasColumnType("text");

                    b.Property<string>("NomeProjeto")
                        .IsRequired()
                        .HasColumnType("text");

                    b.Property<decimal?>("PrecoHora")
                        .HasColumnType("numeric");

                    b.HasKey("IdProjeto");

                    b.ToTable("Projetos");
                });

            modelBuilder.Entity("WebApplication2.Entities.Tarefa", b =>
                {
                    b.Property<decimal>("IdTarefa")
                        .HasColumnType("numeric");

                    b.Property<DateOnly?>("DtFim")
                        .HasColumnType("date");

                    b.Property<DateOnly?>("DtInicio")
                        .HasColumnType("date");

                    b.Property<decimal?>("HrFim")
                        .HasColumnType("numeric");

                    b.Property<decimal?>("HrInicio")
                        .HasColumnType("numeric");

                    b.Property<decimal>("IdProjeto")
                        .HasColumnType("numeric");

                    b.Property<string>("NomeTarefa")
                        .IsRequired()
                        .HasColumnType("text");

                    b.HasKey("IdTarefa");

                    b.ToTable("Tarefas");
                });

            modelBuilder.Entity("WebApplication2.Entities.Utilizador", b =>
                {
                    b.Property<decimal>("IdUtilizador")
                        .HasColumnType("numeric");

                    b.Property<decimal?>("NHabitualHoras")
                        .HasColumnType("numeric");

                    b.Property<string>("Nome")
                        .IsRequired()
                        .HasColumnType("text");

                    b.Property<string>("Password")
                        .IsRequired()
                        .HasColumnType("text");

                    b.Property<string>("Username")
                        .IsRequired()
                        .HasColumnType("text");

                    b.HasKey("IdUtilizador");

                    b.ToTable("Utilizadores");
                });

            modelBuilder.Entity("WebApplication2.Entities.Membro", b =>
                {
                    b.HasOne("WebApplication2.Entities.Projeto", "IdProjetoNavigation")
                        .WithMany("Membros")
                        .HasForeignKey("IdProjeto")
                        .OnDelete(DeleteBehavior.Cascade)
                        .IsRequired();

                    b.HasOne("WebApplication2.Entities.Utilizador", "IdUtilizadorNavigation")
                        .WithMany("Membros")
                        .HasForeignKey("IdUtilizador")
                        .OnDelete(DeleteBehavior.Cascade)
                        .IsRequired();

                    b.Navigation("IdProjetoNavigation");

                    b.Navigation("IdUtilizadorNavigation");
                });

            modelBuilder.Entity("WebApplication2.Entities.Projeto", b =>
                {
                    b.HasOne("WebApplication2.Entities.Utilizador", "IdUtilizadorNavigation")
                        .WithMany("Projetos")
                        .HasForeignKey("IdUtilizador")
                        .OnDelete(DeleteBehavior.Cascade)
                        .IsRequired();

                    b.Navigation("IdUtilizadorNavigation");
                });

            modelBuilder.Entity("WebApplication2.Entities.Tarefa", b =>
                {
                    b.HasOne("WebApplication2.Entities.Projeto", "IdProjetoNavigation")
                        .WithMany("Tarefas")
                        .HasForeignKey("IdProjeto")
                        .OnDelete(DeleteBehavior.Cascade)
                        .IsRequired();

                    b.Navigation("IdProjetoNavigation");
                });

            modelBuilder.Entity("WebApplication2.Entities.Projeto", b =>
                {
                    b.Navigation("Membros");
                });

            modelBuilder.Entity("WebApplication2.Entities.Utilizador", b =>
                {
                    b.Navigation("Membros");

                    b.Navigation("Projetos");
                });
#pragma warning restore 612, 618
        }
    }
}