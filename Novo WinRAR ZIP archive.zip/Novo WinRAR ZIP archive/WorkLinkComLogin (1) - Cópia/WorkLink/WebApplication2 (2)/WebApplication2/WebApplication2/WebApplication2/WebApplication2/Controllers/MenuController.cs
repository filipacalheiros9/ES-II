﻿
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
namespace WebApplication2.Controllers;

public class MenuController : Controller
{
    public IActionResult Perfil()
    {
        return View();
    }

    public IActionResult AsMinhasEquipas()
    {
        return View();
    }

    public IActionResult CriarProjeto()
    {
        return View();
    }

    public IActionResult Defenicoes()
    {
        return View();
    }
}